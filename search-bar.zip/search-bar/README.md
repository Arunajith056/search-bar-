# search bar 

A Pen created on CodePen.io. Original URL: [https://codepen.io/Arunajith056/pen/dyjLZyr](https://codepen.io/Arunajith056/pen/dyjLZyr).

